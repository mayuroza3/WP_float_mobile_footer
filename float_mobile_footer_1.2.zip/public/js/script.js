//alert("hello");
/*$(function () {
       $('.mydoc-mobile-action-icon-label').css('color', 'red');
});*/