<?php
class FMFSettingPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings Admin', 
            'Mobile Footer', 
            'manage_options', 
            'my-setting-admin', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'my_option_name' );
        ?>
        <div class="wrap">
            <!--<h1>My Settings</h1>-->
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'my_option_group' );
                do_settings_sections( 'my-setting-admin' );
			      ?>
  			<div>
          <span class="desciption">Please upload images with 48*48 for better result <br/>Select images one by one and Save</span>
    		</div>          
        <?php
 				 global $wpdb;
  				   if ( !empty( $_POST['my_option_name[image_1]'] ) ) {
    						$image_url1 = $_POST['my_option_name[image_1]'];
               	
    						$wpdb->insert( 'images', array( 'image_1' => $image_url1 ), array( '%s' ) ); 
  					}
  				   if ( !empty( $_POST['my_option_name[image_2]'] ) ) {
    						$image_url2 = $_POST['my_option_name[image_2]'];
               	
    						$wpdb->insert( 'images', array( 'image_2' => $image_url2 ), array( '%s' ) ); 
  					}
  				   if ( !empty( $_POST['my_option_name[image_3]'] ) ) {
    						$image_url3 = $_POST['my_option_name[image_3]'];
               	
    						$wpdb->insert( 'images', array( 'image_3' => $image_url3 ), array( '%s' ) ); 
  					}
  				   if ( !empty( $_POST['my_option_name[image_4]'] ) ) {
    						$image_url4 = $_POST['my_option_name[image_4]'];
               	
    						$wpdb->insert( 'images', array( 'image_4' => $image_url4 ), array( '%s' ) ); 
  					}      
				?>
     
            <?php        
                submit_button();
      
            ?>			
      </form>
			
		<h1>Reset Defaults</h1>
		<form method="post" action="">
			<p class="submit">
        <span class="notice notice-error is-dismissible " style="margin: 10px;padding: 10px;padding-right: 50px;"> Once the reset is done you can't get your data back. Procced carefully!!!</span><br/>
				<input name="reset" class="button button-primary" type="submit" value="Reset to default settings" style="margin-top:20px;">
				<input type="hidden" name="action" value="reset" /> 
			</p>
		</form>	
			
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'my_option_group', // Option group
            'my_option_name', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id2', // ID
            'Mobile Footer Setting', // Title
            array( $this, 'print_section_info2' ), // Callback
            'my-setting-admin' // Page
        );
        add_settings_field(
            'mobile_number', // ID
            'Mobile Number', // Title 
            array( $this, 'mobile_number_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
		add_settings_field(
            'mobile_number_title', // ID
            'Mobile Number Title', // Title 
            array( $this, 'mobile_number_title_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
        add_settings_field(
            'email', // ID
            'Email', // Title 
            array( $this, 'email_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );      
        add_settings_field(
            'email_title', // ID
            'Email Title', // Title 
            array( $this, 'email_title_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );     
        add_settings_field(
            'map_id', // ID
            'Map Location', // Title 
            array( $this, 'map_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );

        add_settings_field(
            'map_id_title', // ID
            'Map Location Title', // Title 
            array( $this, 'map_title_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );
       add_settings_field(
            'app_id', // ID
            'Waze URL', // Title 
            array( $this, 'app_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );
        add_settings_field(
            'app_id_title', // ID
            'Waze URL Title', // Title 
            array( $this, 'app_title_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );
        add_settings_field(
            'image_1', // ID
            'Caller Image', // Title 
            array( $this, 'image_1_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
        add_settings_field(
            'image_2', // ID
            'Application Image', // Title 
            array( $this, 'image_2_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
        add_settings_field(
            'image_3', // ID
            'Map Image', // Title 
            array( $this, 'image_3_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );   
        add_settings_field(
            'image_4', // ID
            'Mail Image', // Title 
            array( $this, 'image_4_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
        add_settings_field(
            'background_color', // ID
            'Background Color', // Title 
            array( $this, 'background_color_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
        add_settings_field(
            'font_color', // ID
            'Font Color', // Title 
            array( $this, 'font_color_callback' ), // Callback
            'my-setting-admin', // Page
            'setting_section_id2' // Section           
        );  
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['id_number'] ) )
            $new_input['id_number'] = absint( $input['id_number'] );

        if( isset( $input['title'] ) )
            $new_input['title'] = sanitize_text_field( $input['title'] );
        
        if( isset( $input['mobile_number'] ) )
            $new_input['mobile_number'] = sanitize_text_field( $input['mobile_number'] );
        if( isset( $input['email'] ) )
            $new_input['email'] = sanitize_text_field( $input['email'] );
        if( isset( $input['map_id'] ) )
            $new_input['map_id'] = sanitize_text_field( $input['map_id'] );
        if( isset( $input['app_id'] ) )
            $new_input['app_id'] = sanitize_text_field( $input['app_id'] );  

        if( isset( $input['mobile_number_title'] ) )
            $new_input['mobile_number_title'] = sanitize_text_field( $input['mobile_number_title'] );
        if( isset( $input['email_title'] ) )
            $new_input['email_title'] = sanitize_text_field( $input['email_title'] );
        if( isset( $input['map_id_title'] ) )
            $new_input['map_id_title'] = sanitize_text_field( $input['map_id_title'] );
        if( isset( $input['app_id_title'] ) )
            $new_input['app_id_title'] = sanitize_text_field( $input['app_id_title'] );  

        if( isset( $input['image_1'] ) )
            $new_input['image_1'] = sanitize_text_field( $input['image_1'] );  
        if( isset( $input['image_2'] ) )
            $new_input['image_2'] = sanitize_text_field( $input['image_2'] );  
        if( isset( $input['image_3'] ) )
            $new_input['image_3'] = sanitize_text_field( $input['image_3'] );  
        if( isset( $input['image_3'] ) )
            $new_input['image_4'] = sanitize_text_field( $input['image_4'] );  

        if( isset( $input['background_color'] ) )
            $new_input['background_color'] = sanitize_text_field( $input['background_color'] );  
        if( isset( $input['font_color'] ) )
            $new_input['font_color'] = sanitize_text_field( $input['font_color'] );        
  
		
        return $new_input;
    }


    /** 
     * Print the Section text
     */
    public function print_section_info2()
    {
        print 'Enter your detail for Mobile footer:';
    }

    public function mobile_number_callback()
    {
        printf(
            '<input type="text" id="mobile_number" name="my_option_name[mobile_number]" value="%s" />',
            isset( $this->options['mobile_number'] ) ? esc_attr( $this->options['mobile_number']) : ''
        );
    }

    public function mobile_number_title_callback()
    {
        printf(
            '<input type="text" id="mobile_number_title" name="my_option_name[mobile_number_title]" value="%s" />',
            isset( $this->options['mobile_number_title'] ) ? esc_attr( $this->options['mobile_number_title']) : ''
        );
    }

    public function email_callback()
    {
        printf(
            '<input type="text" id="email" name="my_option_name[email]" value="%s" />',
            isset( $this->options['email'] ) ? esc_attr( $this->options['email']) : ''
        );
    }

    public function email_title_callback()
    {
        printf(
            '<input type="text" id="email_title" name="my_option_name[email_title]" value="%s" />',
            isset( $this->options['email_title'] ) ? esc_attr( $this->options['email_title']) : ''
        );
    }
  
    public function map_callback()
    {
        printf(
            '<input type="text" id="map_id" name="my_option_name[map_id]" value="%s" />',
            isset( $this->options['map_id'] ) ? esc_attr( $this->options['map_id']) : ''
        );
    }

    public function map_title_callback()
    {
        printf(
            '<input type="text" id="map_id_title" name="my_option_name[map_id_title]" value="%s" />',
            isset( $this->options['map_id_title'] ) ? esc_attr( $this->options['map_id_title']) : ''
        );
    }
  
    public function app_callback()
    {
        printf(
            '<input type="text" id="app_id" name="my_option_name[app_id]" value="%s" />',
            isset( $this->options['app_id'] ) ? esc_attr( $this->options['app_id']) : ''
        );
    }

  	public function app_title_callback()
    {
        printf(
            '<input type="text" id="app_id_title" name="my_option_name[app_id_title]" value="%s" />',
            isset( $this->options['app_id_title'] ) ? esc_attr( $this->options['app_id_title']) : ''
        );
    }

  public function image_1_callback()
    {
        printf(
            '<img id="imagetag_1" src="'.esc_attr( $this->options['image_1']).'" height="48px" width="48px" class="icon_images" />
            <input id="image_1" type="text" name="my_option_name[image_1]"  value="%s" />
              <input id="upload-button1" type="button" class="button" value="Upload Image" />',
            isset( $this->options['image_1'] ) ? esc_attr( $this->options['image_1']) : ''
        );
    }
  public function image_2_callback()
    {
        printf(
            '<img id="imagetag_2" src="'.esc_attr( $this->options['image_2']).'" height="48px" width="48px" class="icon_images"/> 
            <input id="image_2" type="text" name="my_option_name[image_2]"  value="%s" />
              <input id="upload-button2" type="button" class="button" value="Upload Image" />',
            isset( $this->options['image_2'] ) ? esc_attr( $this->options['image_2']) : ''
        );
    }
  public function image_3_callback()
    {
        printf(
            '<img id="imagetag_3" src="'.esc_attr( $this->options['image_3']).'" height="48px" width="48px" class="icon_images" />
            <input id="image_3" type="text" name="my_option_name[image_3]"  value="%s" />
              <input id="upload-button3" type="button" class="button" value="Upload Image" />',
            isset( $this->options['image_3'] ) ? esc_attr( $this->options['image_3']) : ''
        );
    }
   public function image_4_callback()
    {
      		printf(
            '<img id="imagetag_4" src="'.esc_attr( $this->options['image_4']).'" height="48px" width="48px" class="icon_images" /> 
            <input id="image_4" type="text" name="my_option_name[image_4]"  value="%s" />
              <input id="upload-button4" type="button" class="button" value="Upload Image" />',
            isset( $this->options['image_4'] ) ? esc_attr( $this->options['image_4']) : ''
        );
    } 
    public function background_color_callback()
    {
      		printf(
            ' <input id="background_color" type="text" name="my_option_name[background_color]"  value="%s" class="color-picker" data-alpha="true"/>',
            isset( $this->options['background_color'] ) ? esc_attr( $this->options['background_color']) : ''
        );
    } 

	public function font_color_callback()
    {
      		printf(
            ' <input id="font_color" type="text" name="my_option_name[font_color]"  value="%s" class="color-picker" data-alpha="true"/>',
            isset( $this->options['font_color'] ) ? esc_attr( $this->options['font_color']) : ''
        );
    }
	
}