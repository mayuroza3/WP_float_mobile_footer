<?php 
	
// display footer only in mobile screen
	function display_footer() {
		$option = (get_option('my_option_name'));
		if($option['background_color'] == "") {
			$option['background_color'] ="rgba(0,0,0,0.4)";
		}
		if($option['font_color'] == "") {
			$option['font_color'] ="rgba(255,255,255,1)";
		}
		if($option['mobile_number'] == "") {
			$option['mobile_number'] ="9624265729";
		}
		if($option['mobile_number_title'] == "") {
			$option['mobile_number_title'] ="Call Us";
		}
		if($option['app_id'] == "") {
			$option['app_id'] ="23.00307,72.59708";
		}
		if($option['app_id_title'] == "") {
			$option['app_id_title'] ="Waze";
		}
		if($option['map_id'] == "") {
			$option['map_id'] ="Skigle";
		}
		if($option['map_id_title'] == "") {
			$option['map_id_title'] ="Map";
		}
		if($option['email'] == "") {
			$option['email'] ="mayuroza3@gmail.com";
		}
		if($option['email_title'] == "") {
			$option['email_title'] ="Mail";
		}
		$images_path = plugins_url('images',__FILE__ );
		if($option['image_1'] == "") {
			$option['image_1'] = $images_path."/call.png";
		}
		if($option['image_2'] == "") {
			$option['image_2'] =  $images_path."/app.png";
		}
		if($option['image_3'] == "") {
			$option['image_3'] =  $images_path."/map.png";
		}
		if($option['image_4'] == "") {
			$option['image_4'] =  $images_path."/mail.png";
		}
?>
  
<footer class="mobile-sticky-footer visible-xs-block" style="background:<?php echo $option['background_color'];?>;">
     <div class="container">
         <div class="row">
             <div class="col-xs-3 no-pad ">
				<a href="tel:<?php echo $option['mobile_number'];?>" class="bg_1 mydoc-mobile-action-icon mydoc-mobile-action-icon-call popmake-9454" style="background-image:url('<?php echo $option['image_1'];?>')"></a>
                <label class="mydoc-mobile-action-icon-label"><span style="color:<?php echo $option['font_color'];?>"><?php echo $option['mobile_number_title'];?></span></label>
             </div>
             <div class="col-xs-3 no-pad ">   <!-- fb://facewebmodal/f?href=--> 
				
                <a href="waze://?ll=<?php echo $option['app_id'];?>&navigate=yes" class="bg_2 mydoc-mobile-action-icon mydoc-mobile-action-icon-waze" style="background-image:url('<?php echo $option['image_2'];?>')" ></a>
				
                <label class="mydoc-mobile-action-icon-label"><span style="color:<?php echo $option['font_color'];?>"><?php echo $option['app_id_title'];?></span></label>
             </div>
             <div class="col-xs-3 no-pad ">
				<?php if(strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false){?>
                <a href="geo:0,0?q=<?php echo $option['map_id'];?>" class="bg_3 mydoc-mobile-action-icon mydoc-mobile-action-icon-gmap" style="background-image:url('<?php echo $option['image_3'];?>')"></a>
				<?php }
				elseif( strpos($_SERVER['HTTP_USER_AGENT'], 'iPod') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') !== false
						|| strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false){?>
				<a href="//maps.apple.com/?q=<?php echo $option['map_id'];?>" class="bg_3 mydoc-mobile-action-icon mydoc-mobile-action-icon-gmap" style="background-image:url('<?php echo $option['image_3'];?>')"></a>
				<?php
				}?> 
                 <label class="mydoc-mobile-action-icon-label"><span style="color:<?php echo $option['font_color'];?>"><?php echo $option['map_id_title'];?></span></label>
             </div>
             <div class="col-xs-3 no-pad ">          
                 <a href="mailto:<?php echo $option['email']; ?>" class="bg_4 mydoc-mobile-action-icon mydoc-mobile-action-icon-mydochelp" style="background-image:url('<?php echo $option['image_4'];?>')"></a>
                 <label class="mydoc-mobile-action-icon-label"><span style="color:<?php echo $option['font_color'];?>"><?php echo $option['email_title'];?></span></label>
             </div>
         </div>
     </div>
</footer>
<?php
}

