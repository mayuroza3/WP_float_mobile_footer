<?php 
function enque_admin_script_style($hook) {
			  // Load only on ?page=mypluginname
        if('settings_page_my-setting-admin' !== $hook ) {
                return;
        } 
  wp_register_style('enque_my_admin_style', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css');
    wp_enqueue_style('enque_my_admin_style');
    wp_register_style('enque_my_admin_style_2',  plugins_url('/css/admin_style.css',__FILE__ ));
    wp_enqueue_style('enque_my_admin_style_2');

    wp_register_script( 'enque_my_admin_script', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js');
    wp_enqueue_script('enque_my_admin_script');
}

add_action( 'admin_enqueue_scripts','enque_admin_script_style');

 /* Add the media uploader script */
  function my_media_lib_uploader_enqueue() {
    wp_enqueue_media();
    wp_register_script( 'media-lib-uploader-js1',  plugins_url( '/js/wp_media_uploader.js' , __FILE__ ), array('jquery') );
    wp_enqueue_script( 'media-lib-uploader-js1' );
    
    wp_enqueue_style( 'wp-color-picker' );
 	wp_enqueue_script( 'wp-color-picker-alpha',  plugins_url('/js/wp-color-picker-alpha.min.js',__FILE__ ), array( 'wp-color-picker' ), false, true );
    wp_enqueue_script( 'custom-script-handle', plugins_url( '/js/custom-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true ); 
  }
  add_action('admin_enqueue_scripts', 'my_media_lib_uploader_enqueue');
  
  add_action( 'admin_enqueue_scripts', 'fmf_add_color_picker' );
function fmf_add_color_picker( $hook ) {
 
    if('settings_page_my-setting-admin' !== $hook ) { 
     
        // Add the color picker css file       
        wp_enqueue_style( 'wp-color-picker' ); 
         
        // Include our custom jQuery file with WordPress Color Picker dependency
        wp_enqueue_script( 'custom-script-handle', plugins_url( '/js/custom-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true ); 
    }
}

/*
$to = "mayuroza3@gmail.com";
$subject = "Learning how to send an Email in WordPress";
$content = "WordPress <b>knowledge<b>";
add_filter( 'wp_mail_content_type', 'set_html_content_type' );
$status = wp_mail($to, $subject, $content);
// Reset content-type to avoid conflicts -- http://core.trac.wordpress.org/ticket/23578
remove_filter( 'wp_mail_content_type', 'set_html_content_type' );

function set_html_content_type() {
	return 'text/html';
}*/