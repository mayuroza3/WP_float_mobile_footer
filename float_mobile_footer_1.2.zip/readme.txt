=== Float Mobile Footer ===
Contributors: mayuroza3
Donate link: http://example.com/
Tags: mobile footer, float mobile  footer, mobile footer, sticky footer
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin makes floating/sticky footer on mobile device. This will make your site enem more attractive in mobile screen.

== Description ==

This plugin makes floating/sticky footer on mobile device. This will make your site enem more attractive in mobile screen. 
In this plugin you will get backend options to select four different images for four different quick access buttons in mobile screen.
You can customize text on all that sections and their according value for further actions. In this plugin you will also get customize your font 
and background of footer.


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Mobile Footer screen to configure the plugin



== Frequently Asked Questions ==
	
	Do you have questions or issues with Float Mobile Footer? Use these support channels appropriately.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.
== Upgrade Notice == 
* A change since the previous version.
* Another change.
== Arbitrary section ==

== A brief Markdown Example ==
